# Define custom variables and functions for use in {{replaceables}}
#
# Use `site_url` to build fully qualified paths
