# Stagger

## Dependencies

 - starlette
 - uvicorn

## Unfiled

    pip3 install --upgrade --user starlette uvicorn aiofiles
